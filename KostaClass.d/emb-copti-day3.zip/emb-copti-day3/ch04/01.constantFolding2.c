#include <stdio.h>

int main(void)
{
	int a, b, c;
	
	a = 10;
	b = a + 20;
	c = b + 30;
	printf("c:%d\n", c);
	
	return c;
}
